package service

import (
	"../LineThrift"
	"../config"
	"../thrift"
	"net/http"
	"fmt"
)

var _ = fmt.Printf
var IsLogin bool = false
var AuthToken string = ""
var Certificate string = ""
var Revision int64 = 0
var MID string = ""
var Application = config.LINE_APPLICATION
var Headers http.Header
var ChannelHeaders http.Header
var Admin = []string{"udd21eb2268832863966556b247b1fd06"}

func TalkService() *LineThrift.TalkServiceClient {
	//fmt.Println("#### TalkService Initiated. ####")
	httpClient, _ := thrift.NewTHttpClient(config.LINE_HOST_DOMAIN+config.LINE_API_QUERY_PATH_FIR)
	buffer := thrift.NewTBufferedTransportFactory(4096)
	trans := httpClient.(*thrift.THttpClient)
	trans.SetHeader("User-Agent",config.USER_AGENT)
	trans.SetHeader("X-Line-Application",config.LINE_APPLICATION)
	trans.SetHeader("X-Line-Carrier",config.CARRIER)
	trans.SetHeader("X-Line-Access",AuthToken)
  //trans.SetHeader("Connection","Keep-Alive")
	buftrans, _ := buffer.GetTransport(trans)
	compactProtocol := thrift.NewTCompactProtocolFactory()
	return LineThrift.NewTalkServiceClientFactory(buftrans, compactProtocol)
}

func PollService() *LineThrift.TalkServiceClient {
	httpClient, _ := thrift.NewTHttpClient(config.LINE_HOST_DOMAIN+config.LINE_POLL_QUERY_PATH_FIR)
	buffer := thrift.NewTBufferedTransportFactory(4096)
	trans := httpClient.(*thrift.THttpClient)
	trans.SetHeader("User-Agent",config.USER_AGENT)
	trans.SetHeader("X-Line-Application",config.LINE_APPLICATION)
	trans.SetHeader("X-Line-Carrier",config.CARRIER)
	trans.SetHeader("X-Line-Access",AuthToken)
  //trans.SetHeader("Connection","Keep-Alive")
	buftrans, _ := buffer.GetTransport(trans)
	compactProtocol := thrift.NewTCompactProtocolFactory()
	return LineThrift.NewTalkServiceClientFactory(buftrans, compactProtocol)
}

func AuthService() *LineThrift.TalkServiceClient {
	httpClient, _ := thrift.NewTHttpClient(config.LINE_HOST_DOMAIN+config.LINE_AUTH_QUERY_PATH)
	buffer := thrift.NewTBufferedTransportFactory(4096)
	trans := httpClient.(*thrift.THttpClient)
	trans.SetHeader("User-Agent",config.USER_AGENT)
	trans.SetHeader("X-Line-Application",config.LINE_APPLICATION)
	trans.SetHeader("X-Line-Carrier",config.CARRIER)
	trans.SetHeader("X-Line-Access",AuthToken)
  trans.SetHeader("Connection","Keep-Alive")
	buftrans, _ := buffer.GetTransport(trans)
	compactProtocol := thrift.NewTCompactProtocolFactory()
	return LineThrift.NewTalkServiceClientFactory(buftrans, compactProtocol)
}

func LoginZService() *LineThrift.AuthServiceClient {
	httpClient, _ := thrift.NewTHttpClient(config.LINE_HOST_DOMAIN+config.LINE_LOGIN_QUERY_PATH)
	buffer := thrift.NewTBufferedTransportFactory(4096)
	trans := httpClient.(*thrift.THttpClient)
	trans.SetHeader("User-Agent",config.USER_AGENT)
	trans.SetHeader("X-Line-Application",config.LINE_APPLICATION)
	trans.SetHeader("X-Line-Carrier",config.CARRIER)
	trans.SetHeader("X-Line-Access",AuthToken)
  trans.SetHeader("Connection","Keep-Alive")
	buftrans, _ := buffer.GetTransport(trans)
	compactProtocol := thrift.NewTCompactProtocolFactory()
	return LineThrift.NewAuthServiceClientFactory(buftrans, compactProtocol)
}

